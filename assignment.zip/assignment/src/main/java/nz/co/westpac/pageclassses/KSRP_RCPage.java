package nz.co.westpac.pageclassses;

import nz.co.westpac.core.HTMLResultsReport;
import nz.co.westpac.core.WrapperClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class KSRP_RCPage {

	WebDriver driver;
	
	@FindBy(xpath = "//span[contains(text(),'Westpac KiwiSaver Scheme Risk Profiler')]")
	WebElement kiwiSaverCalculatorPageHeading;

	@FindBy(xpath = "//a[text()='Click here to get started.']")
	WebElement kiwiSaverCalGetStartedButton;
	
	@FindBy(xpath = "//h1[contains(text(),'KiwiSaver Retirement Calculator')]")
	WebElement kiwiSaverCalculator;
	
	@FindBy(xpath = "//div[@label='Current age']//i[@class='icon']")
	WebElement kscCurrentAgeInfoIcon;
	
	@FindBy(xpath = "//div[@label='Employment status']//i[@class='icon']")
	WebElement kscEmpStatusInfoIcon;
	
	@FindBy(xpath = "//div[@label='Employment status']//p")
	WebElement kscEmpStatusInfoMsg;
	
	@FindBy(xpath = "//div[@label='Prescribed investor rate (PIR)']//i[@class='icon']")
	WebElement kscPrescribedInvestorRateInfoIcon;
	
	@FindBy(xpath = "//div[@label='Prescribed investor rate (PIR)']//p")
	WebElement kscPrescribedInvestorRateInfoMsg;
	
	@FindBy(xpath = "//div[@label='Current KiwiSaver balance']//i[@class='icon']")
	WebElement kscCurrentKiwiSaverbalanceInfoIcon;
	
	@FindBy(xpath = "//div[@label='Current KiwiSaver balance']//p")
	WebElement kscCurrentKiwiSaverbalanceInfoMsg;
	
	@FindBy(xpath = "//div[@label='Voluntary contributions']//i[@class='icon']")
	WebElement kscVoluntaryContributionsInfoIcon;
	
	@FindBy(xpath = "//div[@label='Voluntary contributions']//p")
	WebElement kscVoluntaryContributionsInfoMsg;
	
	@FindBy(xpath = "//div[@label='Risk profile']//i[@class='icon']")
	WebElement kscRiskprofileInfoIcon;
	
	@FindBy(xpath = "//div[@label='Risk profile']//p")
	WebElement kscRiskprofileInfoMsg;
	
	@FindBy(xpath = "//div[@label='Savings goal at retirement']//i[@class='icon']")
	WebElement kscSavingsGoalAtRetirementInfoIcon;
	
	@FindBy(xpath = "//div[@label='Savings goal at retirement']//p")
	WebElement kscSavingsGoalAtRetirementInfoMsg;
	
	@FindBy(css = "p")
	WebElement infoMessage;
	
	@FindBy(xpath = "//div[@id='calculator-embed']/iframe")
	WebElement calculatorFrame;
	
	@FindBy(xpath = "//div[@label='Current age']//input")
	WebElement calculatorAgeInput;
	
	public WrapperClass wraperClass = new WrapperClass();
	public HTMLResultsReport HTMLResult = new HTMLResultsReport();
	public String strMessage;
	public Boolean TRUE = Boolean.TRUE;
	public Boolean FALSE = Boolean.FALSE;

	public KSRP_RCPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public boolean verifyKSCHomePage() {
		wraperClass.switchFrame(0);
		wraperClass.waitForElement(kiwiSaverCalculatorPageHeading);
		return kiwiSaverCalculatorPageHeading.isDisplayed();
	}
	
	public void navigateToKSCCalculator() {
		wraperClass.scrollWindowDown();
		wraperClass.performMouseOver(kiwiSaverCalGetStartedButton);
		wraperClass.click(kiwiSaverCalGetStartedButton);
	}
	
	public void switchToCalFrame() {
		wraperClass.staticWait(3000);
		wraperClass.waitForElement(calculatorFrame);
		wraperClass.switchFrame(calculatorFrame);
	}

	public void verifyCurrentAgeInfromationIcon(String strExpectedMsg) {
		try {
			switchToCalFrame();
			wraperClass.setText(calculatorAgeInput, "55");
			wraperClass.waitForClickable(kscCurrentAgeInfoIcon);
			if (kscCurrentAgeInfoIcon.isDisplayed()) {
				kscCurrentAgeInfoIcon.click();
				HTMLResult.AddHtml_Report("Current Age Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(infoMessage);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Current Age Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Current Age Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Current Age Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Current Age Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifyEmploymentStatusInfoIcon(String strExpectedMsg) {
		try {
			if (kscEmpStatusInfoIcon.isDisplayed()) {
				kscEmpStatusInfoIcon.click();
				HTMLResult.AddHtml_Report("Employment Status Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscEmpStatusInfoMsg);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Employment Status Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Employment Status Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Employment Status Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Employment Status Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifyPrescribedInvestorRateInfoIcon(String strExpectedMsg) {
		try {
			if (kscPrescribedInvestorRateInfoIcon.isDisplayed()) {
				kscPrescribedInvestorRateInfoIcon.click();
				HTMLResult.AddHtml_Report("Prescribed Investor Rate Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscPrescribedInvestorRateInfoMsg);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Prescribed Investor Rate Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Prescribed Investor Rate Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Prescribed Investor Rate Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Prescribed Investor Rate Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifyCurrentKiwiSaverbalance(String strExpectedMsg) {
		try {
			if (kscCurrentKiwiSaverbalanceInfoIcon.isDisplayed()) {
				kscCurrentKiwiSaverbalanceInfoIcon.click();
				HTMLResult.AddHtml_Report("Current Kiwi Saver balance Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscCurrentKiwiSaverbalanceInfoMsg);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Current Kiwi Saver balance Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Current Kiwi Saver balance Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Current Kiwi Saver balance Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Current Kiwi Saver balance Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifyVoluntaryContributionsInfoIcon(String strExpectedMsg) {
		try {
			if (kscVoluntaryContributionsInfoIcon.isDisplayed()) {
				kscVoluntaryContributionsInfoIcon.click();
				HTMLResult.AddHtml_Report("Voluntary Contributions Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscVoluntaryContributionsInfoMsg);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Voluntary Contributions Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Voluntary Contributions Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Voluntary Contributions Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Voluntary Contributions Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifyRiskprofileInfoIcon(String strExpectedMsg) {
		try {
			if (kscRiskprofileInfoIcon.isDisplayed()) {
				kscRiskprofileInfoIcon.click();
				HTMLResult.AddHtml_Report("Risk profile Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscRiskprofileInfoMsg);
				if (strMessage.contains(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Risk profile Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Risk profile Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Risk profile Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Risk profile Information Icon is Not displayed.","Fail", FALSE);
		}
    }
	
	public void verifySavingsGoalAtRetirement(String strExpectedMsg) {
		try {
			wraperClass.scrollWindowDown();
			wraperClass.staticWait(1000);
			if (kscSavingsGoalAtRetirementInfoIcon.isDisplayed()) {
				kscSavingsGoalAtRetirementInfoIcon.click();
				HTMLResult.AddHtml_Report("Savings Goal At Retirement Information Icon is displayed.", "Pass", FALSE);
				strMessage = wraperClass.getText(kscSavingsGoalAtRetirementInfoMsg);
				if (strMessage.equals(strExpectedMsg)) {
					HTMLResult.AddHtml_Report("Savings Goal At Retirement Information Messaged Displayed properly.", "Pass", FALSE);
				} else {
					HTMLResult.AddHtml_Report("Savings Goal At Retirement Information Messaged Not Displayed properly.", "Fail", FALSE);
				}
			} else {
				HTMLResult.AddHtml_Report("Savings Goal At Retirement Information Icon is Not displayed.","Fail", FALSE);
			}
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Savings Goal At Retirement Information Icon is Not displayed.","Fail", FALSE);
		}
    }

}