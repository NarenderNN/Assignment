package nz.co.westpac.core;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;


public class CopyOfWrapperClass {

    public static int scenarioRowNumber;
    public static WebDriver driver;
    HTMLResultsReport HTMLResFun = new HTMLResultsReport();

    public CopyOfWrapperClass(WebDriver driver1){
        driver =driver1;
    }
    public void clearAndSetTextBox(String objPropValue, String strValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];
        try{
            if (objProperty.equals("class")) {
                driver.findElement(By.className(objDesc)).click();
                driver.findElement(By.className(objDesc)).clear();
                driver.findElement(By.className(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("css")){
                driver.findElement(By.cssSelector(objDesc)).click();
                driver.findElement(By.cssSelector(objDesc)).clear();
                driver.findElement(By.cssSelector(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("link")){
                driver.findElement(By.linkText(objDesc)).click();
                driver.findElement(By.linkText(objDesc)).clear();
                driver.findElement(By.linkText(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("name")){
                driver.findElement(By.name(objDesc)).click();
                driver.findElement(By.name(objDesc)).clear();
                driver.findElement(By.name(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("id")){
                driver.findElement(By.id(objDesc)).click();
                driver.findElement(By.id(objDesc)).clear();
                driver.findElement(By.id(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("xpath")){
                driver.findElement(By.xpath(objDesc)).click();
                driver.findElement(By.xpath(objDesc)).clear();
                driver.findElement(By.xpath(objDesc)).sendKeys(strValue);
            }

        }
        catch(NoSuchElementException nSEE)
        {
            HTMLResFun.AddHtml_Report("Text didnot set for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
            //nSEE.printStackTrace();
        }
        /*catch (Exception e)
        {
            e.printStackTrace();
        }       */
    }

    public void setTextBox(String objPropValue, String strValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1].toString();

        try{
            if (objProperty.equals("class")) {
                driver.findElement(By.className(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("css")){
                driver.findElement(By.cssSelector(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("link")){
                driver.findElement(By.linkText(objDesc)).sendKeys(strValue);
            }else if(objElement[0].equals("name")){
                driver.findElement(By.name(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("id")){
                driver.findElement(By.id(objDesc)).sendKeys(strValue);
            }
            else if(objElement[0].equals("xpath")){
                driver.findElement(By.xpath(objDesc)).sendKeys(strValue);
            }
        }
        catch(NoSuchElementException nSEE){
            HTMLResFun.AddHtml_Report("Text didnot set for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public String getTextValue(String objPropValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];

        try{
            if (objProperty.equals("class")) {
                return driver.findElement(By.className(objDesc)).getText();
            }
            else if(objElement[0].equals("css")){
                return driver.findElement(By.cssSelector(objDesc)).getText();
            }
            else if(objElement[0].equals("link")){
                return driver.findElement(By.linkText(objDesc)).getText();
            }
            else if(objElement[0].equals("name")){
                return driver.findElement(By.name(objDesc)).getText();
            }
            else if(objElement[0].equals("id")){
                return driver.findElement(By.id(objDesc)).getText();
            }
            else if(objElement[0].equals("xpath")){
                return driver.findElement(By.xpath(objDesc)).getText();
            }
        }
        catch (NoSuchElementException nSEE){
            HTMLResFun.AddHtml_Report("Text didnot get for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
        return "";
    }

    public void clickElement(String objPropValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1].toString();

        try{
            if (objProperty.equals("class"))
                driver.findElement(By.className(objDesc)).click();
            else if(objElement[0].equals("css"))
                driver.findElement(By.cssSelector(objDesc)).click();
            else if(objElement[0].equals("link"))
                driver.findElement(By.linkText(objDesc)).click();
            else if(objElement[0].equals("name"))
                driver.findElement(By.name(objDesc)).click();
            else if(objElement[0].equals("id"))
                driver.findElement(By.id(objDesc)).click();
            else if(objElement[0].equals("xpath"))
                driver.findElement(By.xpath(objDesc)).click();
        }
        catch (NoSuchElementException nSEE){
            HTMLResFun.AddHtml_Report("Click didnot perform for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void selectWebList(String objPropValue, String strValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];
        WebElement selectObj = null;

        try{
            if (objProperty.equals("class"))
                selectObj = driver.findElement(By.className(objDesc));
            else if(objElement[0].equals("css"))
                selectObj = driver.findElement(By.cssSelector(objDesc));
            else if(objElement[0].equals("link"))
                selectObj = driver.findElement(By.linkText(objDesc));
            else if(objElement[0].equals("name"))
                selectObj = driver.findElement(By.name(objDesc));
            else if(objElement[0].equals("id"))
                selectObj = driver.findElement(By.id(objDesc));
            else if(objElement[0].equals("xpath"))
                selectObj = driver.findElement(By.xpath(objDesc));

            new Select(selectObj).selectByVisibleText(strValue);
        }
        catch (NoSuchElementException nSEE){
            HTMLResFun.AddHtml_Report("'"+ strValue + "' is not selected for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void selectRevWebList(String objPropValue, String strValue){
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];
        List <WebElement> listOfObjects;
        listOfObjects = null;

        try{
            if (objProperty.equals("class"))
                listOfObjects = driver.findElements(By.className(objDesc));
            else if(objElement[0].equals("css"))
                listOfObjects = driver.findElements(By.cssSelector(objDesc));
            else if(objElement[0].equals("link"))
                listOfObjects = driver.findElements(By.linkText(objDesc));
            else if(objElement[0].equals("name"))
                listOfObjects = driver.findElements(By.name(objDesc));
            else if(objElement[0].equals("id"))
                listOfObjects = driver.findElements(By.id(objDesc));
            else if(objElement[0].equals("xpath"))
                listOfObjects = driver.findElements(By.xpath(objDesc));


            for( WebElement obj:listOfObjects){
                if(obj.getText().equals(strValue)){
                    obj.click();
                    break;
                }
            }
        }
        catch (NoSuchElementException nSEE){
            HTMLResFun.AddHtml_Report("'"+ strValue + "' is not selected for the object whose description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void validateElementPresent(String objPropValue, String strPassDetails, String strFailDetails, Boolean needScreenShot) {
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];
        String status="Not Verified", strDetails;

        try{
            if (objProperty.equals("class")) {
                if(isElementPresent(By.className(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("css")){
                if(isElementPresent(By.cssSelector(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("link")){
                if(isElementPresent(By.linkText(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("name")){
                if(isElementPresent(By.name(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("id")){
                if(isElementPresent(By.id(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("xpath")){
                if(isElementPresent(By.xpath(objDesc)))
                    status = "PASS";
            }

            if(status.equals("PASS"))
                strDetails = strPassDetails;
            else{
                status = "FAIL";
                strDetails = strFailDetails;
            }
            if(needScreenShot)
                HTMLResFun.AddHtml_Report(strDetails, status, Boolean.TRUE);
            else
                HTMLResFun.AddHtml_Report(strDetails, status);
        }
        catch (NoSuchElementException nSEE){
            //HTMLResFun.AddHtml_Report("Object is not found object  description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void validateElementNotPresent(String objPropValue, String strPassDetails, String strFailDetails, Boolean NeedScreenShot) {
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];

        String status="Not Verified", strDetails;

        try{
            if (objProperty.equals("class")) {
                if(!isElementPresent(By.className(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("css")){
                if(!isElementPresent(By.cssSelector(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("link")){
                if(!isElementPresent(By.linkText(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("name")){
                if(!isElementPresent(By.name(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("id")){
                if(!isElementPresent(By.id(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("xpath")){
                if(!isElementPresent(By.xpath(objDesc)))
                    status = "PASS";
            }
            if(status.equals("PASS"))
                strDetails = strPassDetails;
            else{
                status = "FAIL";
                strDetails = strFailDetails;
            }
            if(NeedScreenShot)
                HTMLResFun.AddHtml_Report(strDetails, status, Boolean.TRUE);
            else
                HTMLResFun.AddHtml_Report(strDetails, status);
        }
        catch (NoSuchElementException nSEE){
            //HTMLResFun.AddHtml_Report("Object is not found object  description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void assertElementPresent(String objPropValue, String strPassDetails, String strFailDetails, Boolean NeedScreenShot) {
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];

        String status="Not Verified", strDetails;

        try{
            if (objProperty.equals("class")) {
                if(isElementPresent(By.className(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("css")){
                if(isElementPresent(By.cssSelector(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("link")){
                if(isElementPresent(By.linkText(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("name")){
                if(isElementPresent(By.name(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("id")){
                if(isElementPresent(By.id(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("xpath")){
                if(isElementPresent(By.xpath(objDesc)))
                    status = "PASS";
            }

            if(status.equals("PASS"))
                strDetails = strPassDetails;
            else{
                status = "FAIL";
                strDetails = strFailDetails;
            }
            if(NeedScreenShot)
                HTMLResFun.AddHtml_Report(strDetails, status, Boolean.TRUE);
            else{
                HTMLResFun.AddHtml_Report(strDetails, status);
                driver.quit();
            }
        }
        catch (NoSuchElementException nSEE){
            //HTMLResFun.AddHtml_Report("Object is not found object  description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public void assertElementNotPresent(String objPropValue, String strPassDetails, String strFailDetails, Boolean NeedScreenShot) {
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];

        String status="Not Verified", strDetails;

        try{
            if (objProperty.equals("class")) {
                if(!isElementPresent(By.className(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("css")){
                if(!isElementPresent(By.cssSelector(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("link")){
                if(!isElementPresent(By.linkText(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("name")){
                if(!isElementPresent(By.name(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("id")){
                if(!isElementPresent(By.id(objDesc)))
                    status = "PASS";
            }
            else if(objElement[0].equals("xpath")){
                if(!isElementPresent(By.xpath(objDesc)))
                    status = "PASS";
            }

            if(status.equals("PASS"))
                strDetails = strPassDetails;
            else{
                status = "FAIL";
                strDetails = strFailDetails;
            }
            if(NeedScreenShot)
                HTMLResFun.AddHtml_Report(strDetails, status, Boolean.TRUE);
            else{
                HTMLResFun.AddHtml_Report(strDetails, status);
                driver.quit();
            }
        }
        catch (NoSuchElementException nSEE){
            //HTMLResFun.AddHtml_Report("Object is not found object  description is : "+ objDesc,"FAIL",Boolean.TRUE);
        }
    }

    public boolean isUIObjectPresent(String objPropValue) {
        String[] objElement = objPropValue.split(";;");
        String objProperty = objElement[0];
        String objDesc = objElement[1];

        if (objProperty.equals("class"))
            return isElementPresent(By.className(objDesc));
        else if(objElement[0].equals("css"))
            return isElementPresent(By.cssSelector(objDesc));
        else if(objElement[0].equals("link"))
            return isElementPresent(By.linkText(objDesc));
        else if(objElement[0].equals("name"))
            return isElementPresent(By.name(objDesc));
        else if(objElement[0].equals("id"))
            return isElementPresent(By.id(objDesc));
        else if(objElement[0].equals("xpath"))
            return isElementPresent(By.xpath(objDesc));
        else
            return Boolean.FALSE;
    }

    public void validateElementInNewWindowAndClose(String objPropValue, String strPassMsg, String strFailMsg, boolean NeedScreenShot){
        Set<String> windows = driver.getWindowHandles();
        Iterator<String> iter = windows.iterator();
        String parent = iter.next();
        driver.switchTo().window(iter.next());
        this.validateElementPresent(objPropValue, strPassMsg, strFailMsg, NeedScreenShot);
        driver.close();
        driver.switchTo().window(parent);
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void waitTime(long iTimeInmsec) throws InterruptedException {
        Thread.sleep(iTimeInmsec);
    }

    public void closeBrowser(){
        driver.quit();
    }

    public DataTable importActionDataSheet(String strSheetName){
    	DataTable excelObj = new DataTable(HTMLResFun.strProjectPath+"//TestData//Scenarios.xls",strSheetName);
        scenarioRowNumber = excelObj.getRowNumber(HTMLResFun.strScenarioName);
        return excelObj;
    }

    public int getCurrentScenarioRowNumber(DataTable excelObj){
        return excelObj.getRowNumber(HTMLResFun.strScenarioName);

    }

    public void launchApplication(String strBrowserType, String strURLToOpen){
        if(strBrowserType.equals("Internet Explorer"))
            driver = new InternetExplorerDriver();
        else if(strBrowserType.equals("FireFox"))
            driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get(strURLToOpen);
    }
}

