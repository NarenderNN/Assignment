package nz.co.westpac.core;

import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/** This is the main Reporting Java Class, which will generate the HTML Reports */
public class HTMLResultsReport {

	public WebDriver driver = WrapperClass.driver;
	public String resultFldrPath;
	static int keyInput[] = { KeyEvent.VK_J, KeyEvent.VK_TAB, KeyEvent.VK_TAB,
			KeyEvent.VK_TAB, KeyEvent.VK_TAB, KeyEvent.VK_ENTER };

	public static String strScriptName, Status;
	public static String strScenarioName;
	int FailNum = 0;

	public static String strProjectPath;
	public static String strProjectPathHTML;// for HTML

	public static int SubReport_SNo = 0;
	public static int SubReport_Pass = 0;
	public static int SubReport_Fail = 0;
	public static int SummaryReport_SNo = 0;
	public static int SummaryReport_Pass = 0;
	public static int SummaryReport_Fail = 0;
	public static int screenshotNo = 0;
	public static File folder_name;
	public static String now_time;
	public static String currentScenarioStatus;
	public static String strApplicationNameHTML;

	public HTMLResultsReport(String strApplicationName) {
		strApplicationNameHTML = strApplicationName;
		strScriptName = strApplicationNameHTML + "_Summary_Report";
	}

	public HTMLResultsReport() {
	}

	//====================================================================================================
    // FunctionName     : ProjectPath
    // Description		: Function to set the Result Folder path
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
	public void ProjectPath() {
		strProjectPath = System.getProperty("user.dir").replace("\\", "//")	+ "//src";
		strProjectPathHTML = System.getProperty("user.dir").replace("\\", "/")+ "/src";
		resultFldrPath = strProjectPath + "//Results";
	}

	//====================================================================================================
    // FunctionName     : folder
    // Description		: Function to create the folder using the time stamp for each execution
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
	public File folder() {
		File dir = new File(resultFldrPath + "/" + now_time);
		dir.mkdir();
		return dir;
	}

	
	//====================================================================================================
    // FunctionName     : Sytem_Time
    // Description		: Function will fetch the current time and converts to suitable folder name format
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
	public String Sytem_Time() {
		String system_time = new SimpleDateFormat("yyyy.MM.dd HH.mm.ss").format(new Date());
		return system_time;
	}

	
	// ====================================================================================================
	// FunctionName : SuiteReport_header
	// Description  : Function to generate the HTML report Header
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void HTMLSuiteReport_header() {
		try {
			ProjectPath();
			now_time = Sytem_Time();
			folder_name = folder();
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(folder_name, strScriptName + ".html"), true));
			out.write("<html>");
			out.write("<head>");
			out.write("<meta http-equiv= Content-Language content= en-us>");
			out.write("<meta http-equiv= Content-Type content= text/html; charset=windows-1252>");
			out.write("<title>Automation Test Execution Results </title>");
			out.write("</head>");
			out.write("<body>");
			out.write("<blockquote>");
			out.write("<p align=center><img src='" + strProjectPathHTML + "/Results/" + strApplicationNameHTML + ".PNG' alt= "
					+ strApplicationNameHTML + "></p>");
			out.write("<table align=center border=2 bordercolor=#000000 id=table1 width=80% height=31 bordercolorlight=#000000>");
			out.write("<tr bgcolor = aliceblue>");
			out.write("<td COLSPAN = 5");
			out.write("<p align=center><font color=#000080 size=4 face= Copperplate Gothic Bold>Automation Test Execution Results</font><font face= Copperplate Gothic Bold></font> </p>");
			out.write("</td>");
			out.write("</tr>");
			out.write("<tr bgcolor = aliceblue>");
			out.write("<td COLSPAN = 5 >");
			out.write("<p align=center><b><font color=#000080 size=2 face= Verdana>DATE : " + now_time + "");
			out.write("</td>");
			out.write("</tr>");
			out.write("<tr bgcolor= #1560BD>");
			out.write("<td width= 10%");
			out.write("<p align= center><b><font color = #FFFFFF face= Verdana  size= 2 >" + "S No" + "</b></td>");
			out.write("<td width= 30%");
			out.write("<p align= center><b><font color = #FFFFFF face= Verdana  size=2>" + "TestScript" + "</b></td>");
			out.write("<td width=50%>");
			out.write("<p align=center><b><font color = #FFFFFF face= Verdana size= 2>" + "Description" + "</b></td>");
			out.write("<td width=10%>");
			out.write("<p align= center><b><font color = #FFFFFF face= Verdana size= 2>" + "Status" + "</b></td>");
			out.write("</tr>");
			out.write("</blockquote>");
			out.write("</body>");
			out.write("</html>");
			out.close();
		} catch (IOException e) {
			System.out.println("Error: " + e);
		}
	}

	// ====================================================================================================
	// FunctionName : HTMLReport_header
	// Description  : Function to generate the HTML report Header
	// Input Parameter : None
	// Return Value : None
	// ===================================================================================================
	public void HTMLReport_header(String strTestScriptName) {
		try {
			String now_timeReport = Sytem_Time();
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(
					folder_name, strTestScriptName + ".html"), true));
			out.write("<html>");
			out.write("<html>");
			out.write("<head>");
			out.write("<meta http-equiv= Content-Language content= en-us>");
			out.write("<meta http-equiv= Content-Type content= text/html; charset=windows-1252>");
			out.write("<title>" + strTestScriptName
					+ " - Automation Test Execution Results" + "</title>");
			out.write("</head>");
			out.write("<body>");
			out.write("<blockquote>");
			out.write("<p align=center><img src='" + strProjectPathHTML
					+ "/Results/" + strApplicationNameHTML + ".PNG' alt= "
					+ strApplicationNameHTML + "></p>");
			out.write("<table align=center border=2 bordercolor=#000000 id=table1 width=85% height=31 bordercolorlight=#000000>");
			out.write("<tr bgcolor = aliceblue>");
			out.write("<td COLSPAN = 5");
			out.write("<p align=center><font color=#000080 size=4 face= Copperplate Gothic Bold> " + strTestScriptName
					+ "- Automation Test Execution Results</font><font face= Copperplate Gothic Bold></font> </p>");
			out.write("</td>");
			out.write("</tr>");
			out.write("<tr bgcolor = aliceblue>");
			out.write("<td COLSPAN = 5 >");
			out.write("<p align=center><b><font color=#000080 size=2 face= Verdana>DATE : " + now_timeReport + "");
			out.write("</td>");
			out.write("</tr>");
			out.write("<tr bgcolor= #1560BD>");
			out.write("<td width= 10%");
			out.write("<p align= center><b><font color = #FFFFFF face= Verdana  size= 2 >"
					+ "S No" + "</b></td>");
			out.write("<td width=80%>");
			out.write("<p align=center><b><font color = #FFFFFF face= Verdana size= 2>"
					+ "Details" + "</b></td>");
			out.write("<td width=10%>");
			out.write("<p align= center><b><font color = #FFFFFF face= Verdana size= 2>"
					+ "Status" + "</b></td>");
			out.write("</tr>");
			out.write("</blockquote>");
			out.write("</body>");
			out.write("</html>");
			out.close();
		} catch (IOException e) {
			System.out.println("Error: " + e);
		}
	}

	
	// ====================================================================================================
	// FunctionName : AddHtml_SuiteReport
	// Description  : Function to generate the HTML Suite Report
	// Input Parameter : None
	// Return Value : None
	// ===================================================================================================
	public void AddHtml_SuiteReport(String strTestScriptName, String strDescription) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(folder_name, strScriptName + ".html"), true));
			SummaryReport_SNo = 1 + SummaryReport_SNo;
			int strStepNo = SummaryReport_SNo;
			out.write("<tr bgcolor = aliceblue>");
			out.write("<td width=10%>");
			out.write("<p align=center><font face=Verdana size=2>" + strStepNo
					+ "</td>");
			out.write("<td width=30%>");
			out.write("<p align=left><a href=" + strTestScriptName
					+ ".html><font face= Verdana size=2>" + strTestScriptName
					+ "</font></a></td>");
			out.write("<td width=50%>");
			out.write("<p align=left><font face=Verdana size=2>"
					+ strDescription + "</td>");
			out.write("<td height=23 width=10%>");
			if (SubReport_Fail > 0) {
				SummaryReport_Fail = 1 + SummaryReport_Fail;
				out.write("<p align = center><b><font face= Verdana  size= 2 color= #FF0000>"
						+ "FAIL" + "</font></b></td>");
			} else if (SubReport_Pass > 0 & SubReport_Fail == 0) {
				SummaryReport_Pass = 1 + SummaryReport_Pass;
				out.write("<p align = center><b><font face= Verdana size= 2 color= #008000>"
						+ "PASS" + "</font></b></td>");
			} else if (currentScenarioStatus.equals("Stopped")) {
				SummaryReport_Fail = 1 + SummaryReport_Fail;
				out.write("<p align = center><b><font face= Verdana  size= 2 color= #FF0000>"
						+ "Stopped" + "</font></b></td>");
				driver.quit();
			}
			out.write("</tr>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ====================================================================================================
	// FunctionName : AddHtml_Report
	// Description  : Function to add the Results to the HTML pages
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void AddHtml_Report(String strDetails, String Status) {
		try {
			String strTestScriptName = strScenarioName;
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(
					folder_name, strTestScriptName + ".html"), true));
			SubReport_SNo = 1 + SubReport_SNo;
			int strStepNo = SubReport_SNo;
			out.write("<tr bgcolor = aliceblue >");
			out.write("<td width=10%>");
			out.write("<p align=center><font face=Verdana size=2>" + strStepNo
					+ "</td>");
			out.write("<td width=80%>");
			out.write("<p align=left><font face=Verdana size=2>" + strDetails
					+ "</td>");
			out.write("<td height=23 width=10%>");
			if (Status.equals("Pass") || Status.equals("PASS")) {
				SubReport_Pass = 1 + SubReport_Pass;
				out.write("<p align = center><b><font face= Verdana size= 2 color= #008000>"
						+ "PASS" + "</font></b></td>");
			} else if (Status.equals("Fail") || Status.equals("FAIL")) {
				FailNum = FailNum + 1;
				SubReport_Fail = 1 + SubReport_Fail;
				out.write("<p align = center><b><font face= Verdana  size= 2 color= #FF0000>"
						+ "FAIL" + "</font></b></td>");
			} else if (Status.equals("Stopped") || Status.equals("STOPPED")) {
				out.write("<p align = center><b><font face= Verdana  size= 2 color= #FF0000>"
						+ "STOPPED" + "</font></b></td>");
				currentScenarioStatus = "Stopped";
				SubReport_Fail = 1 + SubReport_Fail;
			}
			out.write("</tr>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// ====================================================================================================
	// FunctionName : AddHtml_Report
	// Description : Function to add the Results to the HTML pages
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void AddHtml_Report(String strDetails, String Status, boolean needScreenshot) {
		try {
			String strTestScriptName = strScenarioName;
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(
					folder_name, strTestScriptName + ".html"), true));
			SubReport_SNo = 1 + SubReport_SNo;
			int strStepNo = SubReport_SNo;
			out.write("<tr bgcolor = aliceblue >");
			out.write("<td width=10%>");
			out.write("<p align=center><font face=Verdana size=2>" + strStepNo
					+ "</td>");
			out.write("<td width=80%>");
			out.write("<p align=left><font face=Verdana size=2>" + strDetails
					+ "</td>");
			out.write("<td height=23 width=10%>");
			if (needScreenshot) {
				String screenPathLink = folder_name + "\\screenshot"
						+ screenshotNo + ".jpg";
				screenshotNo = screenshotNo + 1;
				this.TakeScreenshot(screenPathLink);
			}
			if (Status.equals("Pass") || Status.equals("PASS")) {
				SubReport_Pass = 1 + SubReport_Pass;
				out.write("<p align = center><b><font face= Verdana size= 2 color= #008000>"
						+ "PASS" + "</font></b></td>");
				// out.write("<p align = center><a href=\"+ screenPathLink><font face= Verdana size= 2 color= #008000>"
				// + "PASS" + "</font></a></td>");
			} else if (Status.equals("Fail") || Status.equals("FAIL")) {
				FailNum = FailNum + 1;
				SubReport_Fail = 1 + SubReport_Fail;
				// out.write("<p align = center><b><font face= Verdana  size= 2 color= #FF0000>"
				// + "FAIL" + "</font></b></td>");
				out.write("<p align = center><a href=\"+ screenPathLink><font face= Verdana  size= 2 color= #FF0000>"
						+ "FAIL" + "</font></a></td>");
			} else if (Status.equals("Stopped") || Status.equals("STOPPED")) {
				out.write("<p align = center><a href=\"+ screenPathLink><font face= Verdana  size= 2 color= #FF0000>"
						+ "STOPPED" + "</font></a></td>");
				currentScenarioStatus = "Stopped";
				SubReport_Fail = 1 + SubReport_Fail;
			}
			out.write("</tr>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// ====================================================================================================
	// FunctionName : ResultsSummary
	// Description  : Function to add the Results to the HTML pages
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void ResultsSummary_TestScriptName(String strTestScriptName) {
		try {
			int strTotalNo;
			BufferedWriter out;
			out = new BufferedWriter(new FileWriter(new File(folder_name,
					strTestScriptName + ".html"), true));
			strTotalNo = SubReport_Fail + SubReport_Pass;
			out.write("<tr bgcolor =aliceblue>");
			out.write("<td colspan= 5 align=right>");
			out.write("<table width=300 border=0 cellspacing =1 cellpadding=1>");
			out.write("<tr><td width=45%><b><font color= #000080 size=2 face= Verdana>"
					+ "Total Steps "
					+ "</td><b></font><td width=35%><b><font color= #000080 size=2 face= Verdana>: "
					+ strTotalNo + "</b></font></td></tr>");
			out.write("<tr><td width=45%><b><font color= green face= Verdana size=2>"
					+ "Passed Steps "
					+ "</b></font></td><td width=35%><b><font color= green face= Verdana size=2>: "
					+ SubReport_Pass + "</b></font></td></tr>");
			out.write("<tr><td width=45%><b><font color= #ff3333 face= Verdana size=2>"
					+ "Failed Steps "
					+ "</b></font></td><td width=35%><b><font color= ff3333 face= Verdana size=2>: "
					+ SubReport_Fail + "</b></font></td></tr>");
			out.write("</table>");
			out.write("</td>");
			out.write("</tr>");
			out.write("<table align=center border=0 width=75% height=31>");
			out.write("<tr><td width=100% align=right><a href=" + strScriptName
					+ ".html ><font color= #000080 size=2 face= Verdana><b>"
					+ "<< Summary Report" + "</b></a></font></td></tr>");
			out.write("</table>");
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// ====================================================================================================
	// FunctionName : ResultsSummary_strScriptName
	// Description  : Function to generate the HTML Results Summary for individual test cases
	// Input Parameter : None
	// Return Value : None
	// ===================================================================================================
	public void ResultsSummary_strScriptName() {
		try {
			int strTotalNo;
			BufferedWriter out;
			out = new BufferedWriter(new FileWriter(new File(folder_name,
					strScriptName + ".html"), true));
			strTotalNo = SummaryReport_Fail + SummaryReport_Pass;
			out.write("<tr bgcolor =aliceblue>");
			out.write("<td colspan= 5 align=right>");
			out.write("<table width=350 border=0 cellspacing =1 cellpadding=1>");
			out.write("<tr><td width=45%><b><font color= #000080 size=2 face= Verdana>"
					+ "Total Test Cases "
					+ "</td><b></font><td width=35%><b><font color= #000080 size=2 face= Verdana>: "
					+ strTotalNo + "</b></font></td></tr>");
			out.write("<tr><td width=45%><b><font color= green face= Verdana size=2>"
					+ "Passed Test Cases "
					+ "</b></font></td><td width=35%><b><font color= green face= Verdana size=2>: "
					+ SummaryReport_Pass + "</b></font></td></tr>");
			out.write("<tr><td width=45%><b><font color= #ff3333 face= Verdana size=2>"
					+ "Failed Test Cases "
					+ "</b></font></td><td width=35%><b><font color= ff3333 face= Verdana size=2>: "
					+ SummaryReport_Fail + "</b></font></td></tr>");
			out.write("</table>");
			out.write("</td>");
			out.write("</tr>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// ====================================================================================================
	// FunctionName : AddActionName
	// Description : Function to add the Action Name header
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void AddActionName(String strTestScriptName, String strActionName) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(folder_name, strTestScriptName + ".html"), true));
			out.write("<tr bgcolor=#4682B4>");
			out.write("<td COLSPAN = 3>");
			out.write("<p align=Justify><b><font  color = #FFFFFF size=2  face= verdana >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'"
					+ strActionName + "'</font></b></p>");
			out.write("</td>");
			out.write("</tr>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	// ====================================================================================================
	// FunctionName : TakeScreenshot
	// Description : Function to take the Screenshot
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void TakeScreenshot(String strScreenshotPath) {
		try {
			File scrFile = ((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(strScreenshotPath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

