package nz.co.westpac.core;


public class ApplnUIObjects {
	
    //Login page
    public String Login_UserName_TBx = "id;;username";
    public String Login_Password_TBx = "id;;password";
    public String Login_Login_Btn = "id;;loginButton_label";

    //NRS HomePage
    public String HomePg_Logout_Lnk = "css;;.logout";
    public String HomePg_FindTracer_TBx = "id;;findTracer";
    public String HomePg_FindTracer_Btn = "css;;.findTracerButton";
    public String HomePg_WorkQueue_Tab = "id;;revit_navigation_NavItem_1_label";
    public String HomePg_Inquiry_Tab = "id;;revit_navigation_NavClickItem_1_label";
    public String HomePg_InquiryCustomQuery = "id;;revit_navigation_NavItem_8_label";

    

}
