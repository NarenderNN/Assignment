package nz.co.westpac.pageclassses;

import nz.co.westpac.core.WrapperClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;

	@FindBy(xpath = "//button[text()='Login']")
	WebElement login;

	@FindBy(className = "sw-header-menu")
	WebElement mainMenu;

	@FindBy(xpath = "//a[text()='KiwiSaver']")
	WebElement kiwiSaverOption;

	@FindBy(xpath = "//a[text()='KiwiSaver calculators']")
	WebElement kiwiSaverCalculatorButton;
	

	public WrapperClass wraperClass = new WrapperClass();

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public boolean verifyHomePage() {
		wraperClass.waitForElement(mainMenu);
		return login.isDisplayed();
	}

	public void navigatetToKRC() {
		wraperClass.performMouseOver(kiwiSaverOption);
		wraperClass.click(kiwiSaverCalculatorButton);
	}

}
