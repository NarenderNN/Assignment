package nz.co.westpac.core;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/** This Java Class Contains DataTable (Excel) Utility methods.  Uses JXL API for Excel Operations */
public class DataTable {

    int col,Column_Count,Row_Count;
    int colnNum=0;
    Sheet sheet1 ;
    Workbook wb = null;
    public DataTable(){}

    public DataTable(String Filename, String SheetName){
        File fp = new File(Filename);
        try {
            wb = Workbook.getWorkbook(fp);
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sheet1 = wb.getSheet(SheetName);
        Row_Count = sheet1.getRows();
        Column_Count = sheet1.getColumns();
    }

    
    //====================================================================================================
    // FunctionName     : getCoulmnNumber
    // Description		: Function to Search the given Column Name and will return its index number in the sheet
    // Input Parameter  : Column Name
    // Return Value		: Column Number
    //====================================================================================================
    public int getCoulmnNumber(String strCoulmn){
        for(colnNum=0 ; colnNum<this.sheet1.getColumns();colnNum++){
            if(this.sheet1.getCell(colnNum,0).getContents().equals(strCoulmn))	{
                break;
            }
        }
        return colnNum;
    }
    
    
    //====================================================================================================
    // FunctionName     : LoadDataSheet
    // Description		: Function will Load the given Sheet in to DataTable Object
    // Input Parameter  : File Path, Sheet Name
    // Return Value		: DataTable Object
    //====================================================================================================
    public DataTable LoadDataSheet(String strExcelPath, String strSheet){
    	DataTable excelObj = new DataTable(strExcelPath,strSheet);
        return excelObj;
    }

    
    //====================================================================================================
    // FunctionName     : getRowNumber
    // Description		: Function will search for given string and provide the row number
    // Input Parameter  : Search String (in First Column)
    // Return Value		: Row Number
    //====================================================================================================
    public int getRowNumber(String strRowData){
        int rowNum;
        for(rowNum=1;rowNum<this.sheet1.getRows();rowNum++)
            if(this.sheet1.getCell(0,rowNum).getContents().toString().equals(strRowData))
                break;
        return rowNum;
    }


    //====================================================================================================
    // FunctionName     : getCellData
    // Description		: Function will fetch the particular Cell data based on Row and Column numbers
    // Input Parameter  : Row, Column Values
    // Return Value		: Cell Value
    //====================================================================================================
    public String getCellData(int iRow, int iColumn){
        return this.sheet1.getCell(iColumn, iRow).getContents().toString();
    }

    
    //====================================================================================================
    // FunctionName     : getCellData
    // Description		: Function will fetch the particular Cell data based on Row and Column Name
    // Input Parameter  : Row, Column Values
    // Return Value		: Cell Value
    //====================================================================================================
    public String getCellData(String strColumn, int iRow){
        return this.sheet1.getCell(this.getCoulmnNumber(strColumn), iRow).getContents().toString();
    }

    
    //====================================================================================================
    // FunctionName     : rowCount
    // Description		: Function will fetch the number of rows in the corresponding sheet object
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public int rowCount(){
        return sheet1.getRows();
    }

    
    //====================================================================================================
    // FunctionName     : columnCount
    // Description		: Function will fetch the number of columns in the corresponding sheet object
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public int columnCount(){
        return sheet1.getColumns();
    }

 }