package nz.co.westpac.core;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class DataTable {

    int col,Column_Count,Row_Count;
    int colnNum=0;
    Sheet sheet1 ;
    Workbook wb = null;
    public DataTable(){}

    public DataTable(String Filename, String SheetName){
        File fp = new File(Filename);
        try {
            wb = Workbook.getWorkbook(fp);
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sheet1 = wb.getSheet(SheetName);
        Row_Count = sheet1.getRows();
        Column_Count = sheet1.getColumns();
    }

    public int getCoulmnNumber(String strCoulmn){
        for(colnNum=0 ; colnNum<this.sheet1.getColumns();colnNum++){
            if(this.sheet1.getCell(colnNum,0).getContents().equals(strCoulmn))	{
                break;
            }
        }
        return colnNum;
    }

    public DataTable LoadDataSheet(String strExcelPath, String strSheet){
    	DataTable excelObj = new DataTable(strExcelPath,strSheet);
        return excelObj;
    }

    public int getRowNumber(String strRowData){
        int rowNum;
        for(rowNum=1;rowNum<this.sheet1.getRows();rowNum++)
            if(this.sheet1.getCell(0,rowNum).getContents().toString().equals(strRowData))
                break;
        return rowNum;
    }


    public String getCellData(int iRow, int iColumn){
        return this.sheet1.getCell(iColumn, iRow).getContents().toString();
    }

    public String getCellData(String strColumn, int iRow){
        return this.sheet1.getCell(this.getCoulmnNumber(strColumn), iRow).getContents().toString();
    }

    public int rowCount(){
        return sheet1.getRows();
    }

    public int columnCount(){
        return sheet1.getColumns();
    }

   /* public void writeData(String strData){
        Workbook workbook = Workbook.getWorkbook(new File("book.xls"));
        WritableWorkbook copy = Workbook.createWorkbook(newFile(""), workbook);
        WritableSheet sheet = copy.getSheet(0);
        WritableFont times16font = new WritableFont(WritableFont.TIMES, 20, WritableFont.BOLD);
        WritableCellFormat times16format = new WritableCellFormat (times16font);
        Label label = new Label(3, 4, "Good", times16format);
        sheet.addCell(label);
        Label label1 = new Label(3, 5, "Good", times16format);
        sheet.addCell(label);
        copy.write();
        copy.close();

        element.wd.location_once_scrolled_into_view
    }*/
}