package nz.co.westpac.pageclassses;

import nz.co.westpac.core.HTMLResultsReport;
import nz.co.westpac.core.WrapperClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class KSRP_RCalPage {

	WebDriver driver;
	
	@FindBy(xpath = "//div[@label='Current age']//input")
	WebElement calculatorAgeInput;
	
	@FindBy(xpath = "//div[@label='Employment status']//div[@ng-bind-html='selectedContent']")
	WebElement EmploymentstatusDropDown;
	
	@FindBy(xpath = "//div[@label='Salary or wages per year (before tax)']//input")
	WebElement SalorWagesPerYear;
	
	@FindBy(xpath = "//div[@label='Prescribed investor rate (PIR)']//div[@ng-bind-html='selectedContent']")
	WebElement PIRDropDown;
	
	@FindBy(xpath = "//div[@label='Current KiwiSaver balance']//input")
	WebElement CurrentKSBalance;
	
	@FindBy(xpath = "//div[@label='Voluntary contributions']//input")
	WebElement VoluntaryContributions;
	
	@FindBy(xpath = "//div[@label='Voluntary contributions']//div[@ng-bind-html='selectedContent']")
	WebElement VoluntaryContributionsDropDown;
	
	@FindBy(xpath = "//div[@label='Savings goal at retirement']//input")
	WebElement SavingsGoalAtRetirement;
	
	@FindBy(xpath = "//div[@class='field-group-set'][2]//button")
	WebElement CalcualteKSRProjectionsButton;
	
	@FindBy(xpath = "//div[@class='results-heading']//span[2]")
	WebElement KSRProjectionsResult;
	
	public String DropDownItems = "//span[text()='";
	public String RiskProfile = "//div[@label='Risk profile']//input[@value='";
	public String KSMContribution = "//div[@label='KiwiSaver member contribution']//span[text()='";
	
	
	public WrapperClass wraperClass = new WrapperClass();
	public HTMLResultsReport HTMLResult = new HTMLResultsReport();
	public String strMessage;
	public Boolean TRUE = Boolean.TRUE;
	public Boolean FALSE = Boolean.FALSE;

	public KSRP_RCalPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void calKSRProjects(String age, String empStatus, String salary, String ksmContribution, String PIR, String currentKSB,
			String volContribution, String contFrequency, String riskProfile, String savingGoal, String KSBExpectedAmount) {
		
		String spanText, ksmContributionL, riskProfileL, KSBAmount;
		wraperClass.setText(calculatorAgeInput, age);
		HTMLResult.AddHtml_Report("Enterted Current Age " + age, "Pass", FALSE);
		
		wraperClass.waitForClickable(EmploymentstatusDropDown);
		wraperClass.click(EmploymentstatusDropDown);
		spanText = DropDownItems + empStatus + "']";
		wraperClass.click(wraperClass.findElementByXpath(spanText));
		HTMLResult.AddHtml_Report("Selected Employment Status " + empStatus, "Pass", FALSE);
		
		if (empStatus.equalsIgnoreCase("Employed")) {
			wraperClass.setText(SalorWagesPerYear, salary);
			HTMLResult.AddHtml_Report("Enterted Salary or Wage " + salary, "Pass", FALSE);
			
			ksmContributionL = KSMContribution + ksmContribution + "']";
			wraperClass.click(wraperClass.findElementByXpath(ksmContributionL));
			HTMLResult.AddHtml_Report("Selected KSM Contribution " + ksmContribution, "Pass", FALSE);
		}
		
		if (!(PIR.equals(""))) {
			wraperClass.click(PIRDropDown);
			spanText = DropDownItems + PIR + "']";
			wraperClass.click(wraperClass.findElementByXpath(spanText));
			HTMLResult.AddHtml_Report("Selected PIR  " + PIR, "Pass", FALSE);
		}
		
		wraperClass.setText(CurrentKSBalance, currentKSB);
		HTMLResult.AddHtml_Report("Enterted Current KSB " + currentKSB, "Pass", FALSE);
		wraperClass.setText(VoluntaryContributions, volContribution);
		HTMLResult.AddHtml_Report("Enterted Current Volutary Contribution " + volContribution, "Pass", FALSE);
		
		if (!(contFrequency.equals(""))) {
			wraperClass.click(VoluntaryContributionsDropDown);
			spanText = DropDownItems + contFrequency + "']";
			wraperClass.click(wraperClass.findElementByXpath(spanText));
			HTMLResult.AddHtml_Report("Selected Contribution Frequency  " + contFrequency, "Pass", FALSE);
		}
		
		riskProfileL = RiskProfile + riskProfile.toLowerCase() + "']";
		wraperClass.click(wraperClass.findElementByXpath(riskProfileL));
		HTMLResult.AddHtml_Report("Selected Risk Profile  " + riskProfile, "Pass", FALSE);
		
		wraperClass.setText(SavingsGoalAtRetirement, savingGoal);
		
		if (wraperClass.isElementPresent(CalcualteKSRProjectionsButton)) {
			wraperClass.click(CalcualteKSRProjectionsButton);
		}
		
		KSBAmount = wraperClass.getText(KSRProjectionsResult);
		
		if (KSBAmount.contains(KSBExpectedAmount)) {
			HTMLResult.AddHtml_Report("User is able to Calculate KSB Amount. KSBAmount " + KSBAmount, "Pass", FALSE);
		} else {
			HTMLResult.AddHtml_Report("User is not able to Calculate KSB Amount properly. KSBAmount  " + KSBAmount + " Expected Amount  "  + KSBExpectedAmount, "Fail", FALSE);
		}
		
		
	}
	
/*	public void calKSRProjects() {
		String spanText, ksmContributionL, riskProfileL;
		wraperClass.setText(calculatorAgeInput, "30");
		wraperClass.waitForClickable(EmploymentstatusDropDown);
		wraperClass.click(EmploymentstatusDropDown);
		spanText = DropDownItems + "Employed']";
		wraperClass.click(wraperClass.findElementByXpath(spanText));
		wraperClass.setText(SalorWagesPerYear, "82000");
		ksmContributionL = KSMContribution + "4%']";
		wraperClass.click(wraperClass.findElementByXpath(ksmContributionL));
		wraperClass.click(PIRDropDown);
		spanText = DropDownItems + "10.5%']";
		wraperClass.click(wraperClass.findElementByXpath(spanText));
		wraperClass.setText(CurrentKSBalance,"");
		wraperClass.setText(VoluntaryContributions,"10");
		wraperClass.click(VoluntaryContributionsDropDown);
		spanText = DropDownItems + "One-off']";
		wraperClass.click(wraperClass.findElementByXpath(spanText));
		riskProfileL = RiskProfile + "low']";
		wraperClass.click(wraperClass.findElementByXpath(riskProfileL));
		wraperClass.setText(SavingsGoalAtRetirement,"");
		wraperClass.click(CalcualteKSRProjectionsButton);
		
		System.out.println("Result " + wraperClass.getText(KSRProjectionsResult));
		
	}*/

}
