package nz.co.westpac.core;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/** This Java Class Contains WebDriver wrapper methods and General utility Methods.*/
public class WrapperClass {

	public static int scenarioRowNumber;
	public static WebDriver driver;
	HTMLResultsReport HTMLResFun = new HTMLResultsReport();
	
	// ====================================================================================================
	// FunctionName : setDriver
	// Description : Function to Create appropriate driver object based on user input
	// Input Parameter : Browser Name
	// Return Value : None
	// ====================================================================================================
	public void setDriver(String brwType) {
		try {
			if (brwType.equals("IE")) {
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir").replace("\\","//")+"//lib//IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			} else if (brwType.equals("FireFox"))
				driver = new FirefoxDriver();
			else if (brwType.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir").replace("\\","//")+"//lib//chromedriver.exe");
				driver = new ChromeDriver();
			}
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// ====================================================================================================
	// FunctionName : staticWait
	// Description : Function to wait predefined seconds
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void staticWait(long iTimeInmsec) {
		try {
			Thread.sleep(iTimeInmsec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ====================================================================================================
	// FunctionName : waitForElement
	// Description : Function to wait for element visibility (max 30 Seconds)
	// Input Parameter : WebElement
	// Return Value : None
	// ====================================================================================================
	public void waitForElement(WebElement ele) {
		try {
			WebDriverWait ww = new WebDriverWait(driver, 30);
			ww.until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	// ====================================================================================================
	// FunctionName : waitForClickable
	// Description : Function to wait for element to be clickable (max 6 Seconds)
	// Input Parameter : WebElement
	// Return Value : None
	// ====================================================================================================
	public void waitForClickable(WebElement ele) {
		try {
			int i = 1;
			boolean flag = false;
			do {
				Thread.sleep(2000);
				i++;
				if (ele.isEnabled()) {
					flag = true;
				}				
			} while (i<3 || flag == false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// ====================================================================================================
	// FunctionName : closeBrowser
	// Description : Function to close the Browser
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void closeBrowser() {
		driver.quit();
	}
	
	// ====================================================================================================
	// FunctionName : importActionDataSheet
	// Description : Function to import specific sheet
	// Input Parameter : Sheet Name
	// Return Value : DataTable Object
	// ====================================================================================================
	public DataTable importActionDataSheet(String strSheetName) {
		DataTable excelObj = new DataTable(HTMLResultsReport.strProjectPath + "//TestData//Scenarios.xls", strSheetName);
		scenarioRowNumber = excelObj.getRowNumber(HTMLResultsReport.strScenarioName);
		return excelObj;
	}

	
	// ====================================================================================================
	// FunctionName : getCurrentScenarioRowNumber
	// Description : Function to get the Current Execution Scenario Row Number
	// Input Parameter : Excel Object (Test Data)
	// Return Value : Row Number
	// ====================================================================================================
	public int getCurrentScenarioRowNumber(DataTable excelObj) {
		return excelObj.getRowNumber(HTMLResultsReport.strScenarioName);
	}

	
	// ====================================================================================================
	// FunctionName : launchApplication
	// Description : Function to navigate to specific URL
	// Input Parameter : URL
	// Return Value : None
	// ====================================================================================================
	public void launchApplication(String strURLToOpen) {
		driver.get(strURLToOpen);
	}
	
	
	// ====================================================================================================
	// FunctionName : click
	// Description : Function to wait for the element and click on it
	// Input Parameter : WebElement
	// Return Value : None
	// ====================================================================================================
	public void click(WebElement ele) {
		waitForElement(ele);
		ele.click();
	}
	
	
	// ====================================================================================================
	// FunctionName : setText
	// Description : Function to clear the existing content and set the given value
	// Input Parameter : WebElement, Text
	// Return Value : None
	// ====================================================================================================
	public void setText(WebElement ele,String text) {
		waitForElement(ele);
		ele.clear();
		ele.sendKeys(text);
	}
	
	
	// ====================================================================================================
	// FunctionName : performMouseOver
	// Description : Function to perform mouse over operation on given webelement
	// Input Parameter : WebElement
	// Return Value : None
	// ====================================================================================================
	public void performMouseOver(WebElement ele) {
		Actions builder = new Actions(driver);
		Action mouseOverHome = builder.moveToElement(ele)
		                		.build();
		mouseOverHome.perform();
	}
	
	
	// ====================================================================================================
	// FunctionName : getText
	// Description : Function to retrieve the text property of the element
	// Input Parameter : WebElement
	// Return Value : None
	// ====================================================================================================
	public String getText(WebElement ele) {
		try {
			waitForElement(ele);
			return ele.getText();
		} catch (Exception e) {
			return "";
		}
	}
	
	
	// ====================================================================================================
	// FunctionName : switchFrame
	// Description : Function to switch frame based on Inde
	// Input Parameter : Index
	// Return Value : None
	// ====================================================================================================
	public void switchFrame(int i) {
		driver.switchTo().frame(i);
	}
	
	
	// ====================================================================================================
	// FunctionName : switchFrame
	// Description : Function to switch Frame based on WebElement
	// Input Parameter : URL
	// Return Value : None
	// ====================================================================================================
	public void switchFrame(WebElement ele) {
		driver.switchTo().frame(ele);
	}
	
	
	// ====================================================================================================
	// FunctionName : scrollWindowDown
	// Description : Function to scroll the window down
	// Input Parameter : None
	// Return Value : None
	// ====================================================================================================
	public void scrollWindowDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
	}
	
		
	// ====================================================================================================
	// FunctionName : findElementByXpath
	// Description : Function to find the element by xpath (For Dynamically generated xpaths)
	// Input Parameter : xpath value
	// Return Value : WebElement
	// ====================================================================================================
	public WebElement findElementByXpath(String str) {
		return driver.findElement(By.xpath(str));
	}
	
	
	// ====================================================================================================
	// FunctionName : isElementPresent
	// Description : Function to check whether Element is present or not
	// Input Parameter : WebElement
	// Return Value : True / False
	// ====================================================================================================
	public boolean isElementPresent(WebElement ele) {
		try {
			ele.isDisplayed();
			return true;
		} catch (Exception E) {
			return false;
		}
	}
	
}
