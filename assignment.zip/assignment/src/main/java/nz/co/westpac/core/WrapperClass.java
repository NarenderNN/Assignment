package nz.co.westpac.core;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WrapperClass {

	public static int scenarioRowNumber;
	public static WebDriver driver;
	HTMLResultsReport HTMLResFun = new HTMLResultsReport();
	
	public void setDriver(String brwType) {

		if (brwType.equals("IE")) {
			System.setProperty("webdriver.ie.driver", "D:\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else if (brwType.equals("FireFox"))
			driver = new FirefoxDriver();
		else if (brwType.equals("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:\\SW\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public void clearAndSetTextBox(WebElement ele, String strValue) {
		try {
			ele.click();
			ele.clear();
			ele.sendKeys(strValue);
		} catch (NoSuchElementException nSEE) {
			HTMLResFun.AddHtml_Report(
					"Text didnot set for the object whose description is : "
							+ ele.toString(), "FAIL", Boolean.TRUE);
		}
	}

	public void staticWait(long iTimeInmsec) {
		try {
			Thread.sleep(iTimeInmsec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForElement(WebElement ele) {
		try {
			WebDriverWait ww = new WebDriverWait(driver, 30);
			ww.until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void waitForClickable(WebElement ele) {
		try {
			int i = 1;
			boolean flag = false;
			do {
				Thread.sleep(2000);
				i++;
				if (ele.isEnabled()) {
					flag = true;
				}				
			} while (i<3 || flag == false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closeBrowser() {
		driver.quit();
	}

	public DataTable importActionDataSheet(String strSheetName) {
		DataTable excelObj = new DataTable(HTMLResultsReport.strProjectPath
				+ "//TestData//Scenarios.xls", strSheetName);
		scenarioRowNumber = excelObj
				.getRowNumber(HTMLResultsReport.strScenarioName);
		return excelObj;
	}

	public int getCurrentScenarioRowNumber(DataTable excelObj) {
		return excelObj.getRowNumber(HTMLResultsReport.strScenarioName);
	}

	public void launchApplication(String strURLToOpen) {
		driver.get(strURLToOpen);
	}
	
	public void click(WebElement ele) {
		waitForElement(ele);
		ele.click();
	}
	
	public void setText(WebElement ele,String text) {
		waitForElement(ele);
		ele.clear();
		ele.sendKeys(text);
	}
	
	public void performMouseOver(WebElement ele) {
		Actions builder = new Actions(driver);
		Action mouseOverHome = builder.moveToElement(ele)
		                		.build();
		mouseOverHome.perform();
	}
	
	public String getText(WebElement ele) {
		waitForElement(ele);
		return ele.getText();
	}
	
	public void switchFrame(int i) {
		driver.switchTo().frame(i);
	}
	
	public void switchFrame(WebElement ele) {
		driver.switchTo().frame(ele);
	}
	
	public void scrollWindowDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
	}
	
	public void scrollWindowUP() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(250,0)", "");
	}
	
}
