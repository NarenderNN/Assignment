package nz.co.westpac.assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {
	
	public static void main(String args[]) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\SW\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://www.westpac.co.nz/kiwisaver/calculators/kiwisaver-calculator/");
		driver.manage().window().maximize();
		Thread.sleep(4000);
		String strMsg = "";
		
		WebElement ele = driver.findElement(By.xpath("//div[@id='calculator-embed']/iframe"));
		driver.switchTo().frame(ele);
		driver.findElement(By.xpath("//div[@label='Current age']//i[@class='icon']")).click();
		strMsg = "This calculator has an age limit of 64 years old as you need to be under the age of 65 to join KiwiSaver.";
		System.out.println(driver.findElement(By.cssSelector("p")).getText().equals(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Employment status']//i[@class='icon']")).click();
		strMsg = "If you are earning a salary or wage, select ‘Employed’. Your employer contributions will be automatically calculated at a rate of 3% of your before-tax salary or wages. You can also select ‘Self-employed’ or ‘Not employed’ and then enter below (in the Voluntary contributions field), the amount and frequency of any contributions that you wish to make.";
		System.out.println(driver.findElement(By.xpath("//div[@label='Employment status']//p")).getText().equals(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Prescribed investor rate (PIR)']//i[@class='icon']")).click();
		strMsg = "This is your prescribed investor rate (PIR) for tax purposes. If you don't know what your PIR is, click on the ‘Find My Rate’ button.";
		System.out.println(driver.findElement(By.xpath("//div[@label='Prescribed investor rate (PIR)']//p")).getText().equals(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Current KiwiSaver balance']//i[@class='icon']")).click();
		strMsg = "If you do not have a KiwiSaver account, then leave this field blank.";
		System.out.println(driver.findElement(By.xpath("//div[@label='Current KiwiSaver balance']//p")).getText().equals(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Voluntary contributions']//i[@class='icon']")).click();
		strMsg = "If you are 'Self-Employed' or 'Not employed', you can make direct contributions to your KiwiSaver account. If you are 'Employed', you can make voluntary contributions in addition to your regular employee contributions.";
		System.out.println(driver.findElement(By.xpath("//div[@label='Voluntary contributions']//p")).getText().equals(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Risk profile']//i[@class='icon']")).click();
		strMsg = "The risk profile affects your potential investment returns:";
		System.out.println(driver.findElement(By.xpath("//div[@label='Risk profile']//p")).getText().contains(strMsg));
		
		driver.findElement(By.xpath("//div[@label='Savings goal at retirement']//i[@class='icon']")).click();
		strMsg = "Enter the amount you would like to have saved when you reach your intended retirement age. If you aren’t sure what this amount is, you can leave it blank or use the Sorted Retirement Planner";
		System.out.println(driver.findElement(By.xpath("//div[@label='Savings goal at retirement']//p")).getText().equals(strMsg));
		
		
		
	}
	

}
