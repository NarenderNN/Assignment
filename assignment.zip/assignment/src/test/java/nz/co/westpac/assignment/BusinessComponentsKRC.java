package nz.co.westpac.assignment;

import nz.co.westpac.core.DataTable;
import nz.co.westpac.core.HTMLResultsReport;
import nz.co.westpac.core.WrapperClass;
import nz.co.westpac.pageclassses.HomePage;
import nz.co.westpac.pageclassses.KSRP_RCPage;
import nz.co.westpac.pageclassses.KSRP_RCalPage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** This Java Class Contains Business Component menthods, which will intern call the methods from Corresponding Page Classes */
public class BusinessComponentsKRC {

    public HTMLResultsReport HTMLResult = new HTMLResultsReport();
    public WrapperClass wrapper = new WrapperClass();
    public HomePage homePage = new HomePage(WrapperClass.driver);
    public KSRP_RCPage ksrp_RCPage = new KSRP_RCPage(WrapperClass.driver);
    public KSRP_RCalPage ksrp_RCalPage = new KSRP_RCalPage(WrapperClass.driver);
    Logger logger = LogManager.getLogger(BusinessComponentsKRC.class);

    public static String strBrowser;
    public static String strURL;
    public Boolean TRUE = Boolean.TRUE;
    public Boolean FALSE = Boolean.FALSE;
    
    
    //====================================================================================================
    // FunctionName     : navigateToApplication
    // Description		: Function to Navigate to the Application Home Page
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public void navigateToApplication() {
        try{
        	logger.info("Executing Navigate To Application Method");
            DataTable excelObj = wrapper.importActionDataSheet("GlobalVariables");
            strURL = excelObj.getCellData("ApplicationURL",1);
            wrapper.launchApplication(strURL);
            if (homePage.verifyHomePage()) {
            	HTMLResult.AddHtml_Report("Navigated to KiwiSaver Application.", "Pass", FALSE);  
            } else {
            	HTMLResult.AddHtml_Report("Failed to Navigate KiwiSaver Application.", "Fail", FALSE);  
            }
        } catch(Exception e){
            HTMLResult.AddHtml_Report("Failed to Navigate KiwiSaver Application.", "Stopped", FALSE);
            e.printStackTrace();
            logger.error(e.toString());
        }
    }
    
    
    //====================================================================================================
    // FunctionName     : navigatetToKRC
    // Description		: Function to Navigate to the Risk Profiler & Retirement Calculator Page
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public void navigatetToKRC() {
    	try {
    		logger.info("Executing Navigate To KRC Method");
    		homePage.navigatetToKRC();
			if (ksrp_RCPage.verifyKSCHomePage()) {
				HTMLResult.AddHtml_Report("Navigated to Risk Profiler & Retirement Calculator Page."  , "Pass", FALSE);  
			} else {
				HTMLResult.AddHtml_Report("Failed to Navigate to Risk Profiler & Retirement Calculator Page."  , "Fail", FALSE);  
			}
			ksrp_RCPage.navigateToKSCCalculator();
		} catch (Exception e) {
			HTMLResult.AddHtml_Report("Failed to Navigate to Risk Profiler & Retirement Calculator Page.", "Stopped", FALSE);
            e.printStackTrace();
            logger.error(e.toString());
		}
    }
    
    
    //====================================================================================================
    // FunctionName     : verifyKRCCalculator
    // Description		: Function to validate Risk Profiler & Retirement Calculator Functionality
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public void verifyKRCCalculator() {
    	try {
    		logger.info("Executing Verify KRC Method");
			String age, empStatus, salary, ksmContribution, PIR, currentKSB;
			String volContribution, contFrequency, riskProfile, savingGoal, KSBExpectedAmount;
			int i;
			ksrp_RCPage.switchToCalFrame();
			
			//Loop through the 3 data iterations mentioned in the Test Data Sheet
			for (i=1;i<4;i++) {
				int rowNumber;
				
				//Retrieve the test data from the Test Data Sheet
				DataTable excelObj = wrapper.importActionDataSheet("TestData");
				rowNumber = excelObj.getRowNumber("verifyKRCCalculator" + i);
				age = excelObj.getCellData("age",rowNumber);
				empStatus = excelObj.getCellData("empStatus",rowNumber);
				salary = excelObj.getCellData("salary",rowNumber);
				ksmContribution = excelObj.getCellData("ksmContribution",rowNumber);
				PIR = excelObj.getCellData("PIR",rowNumber);
				currentKSB = excelObj.getCellData("currentKSB",rowNumber);
				volContribution = excelObj.getCellData("volContribution",rowNumber);
				contFrequency = excelObj.getCellData("contFrequency",rowNumber);
				riskProfile = excelObj.getCellData("riskProfile",rowNumber);
				savingGoal = excelObj.getCellData("savingGoal",rowNumber);
				KSBExpectedAmount = excelObj.getCellData("KSBAmount",rowNumber);
				
				ksrp_RCalPage.calKSRProjects(age, empStatus, salary, ksmContribution, PIR, currentKSB, volContribution, contFrequency, riskProfile, savingGoal, KSBExpectedAmount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.toString());
		}
    }
    
    
    //====================================================================================================
    // FunctionName     : verifyInfromationIcons
    // Description		: Function to validate Risk Profiler & Retirement Calculator Information Icons
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public void verifyInfromationIcons() {
    	try {
    		logger.info("Executing Verify KRC Information Icons Method");
			int i;
			DataTable excelObj = wrapper.importActionDataSheet("TestData");
			i = excelObj.getRowNumber("verifyInfromationIcons");
			
			ksrp_RCPage.verifyCurrentAgeInfromationIcon(excelObj.getCellData("CurrentAgeInfoMsg",i));
			ksrp_RCPage.verifyEmploymentStatusInfoIcon(excelObj.getCellData("EmploymentInfoMsg",i));
			ksrp_RCPage.verifyPrescribedInvestorRateInfoIcon(excelObj.getCellData("PIRInfoMsg",i));
			ksrp_RCPage.verifyCurrentKiwiSaverbalance(excelObj.getCellData("KSBInfoMsg",i));
			ksrp_RCPage.verifyVoluntaryContributionsInfoIcon(excelObj.getCellData("VCInfoMsg",i));
			ksrp_RCPage.verifyRiskprofileInfoIcon(excelObj.getCellData("RiskProfileInfoMsg",i));
			ksrp_RCPage.verifySavingsGoalAtRetirement(excelObj.getCellData("SavingsGoalInfoMsg",i));
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.toString());
		}
    }
    
    
    //====================================================================================================
    // FunctionName     : closeApplication
    // Description		: Function to Close the application
    // Input Parameter  : None
    // Return Value		: None
    //====================================================================================================
    public void closeApplication() {
        try{
        	wrapper.closeBrowser();
        } catch(Exception e){
            e.printStackTrace();
            logger.error(e.toString());
        }
    }
   
}
