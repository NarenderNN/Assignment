package nz.co.westpac.assignment;

import java.lang.reflect.Method;

import nz.co.westpac.core.DataTable;
import nz.co.westpac.core.HTMLResultsReport;
import nz.co.westpac.core.WrapperClass;

public class Driver {

	public static void main(String[] args) throws Exception {

		String strApplication = "Westpac_KRC";

		WrapperClass wrapper = new WrapperClass();
		HTMLResultsReport HTMLres = new HTMLResultsReport(strApplication);
		HTMLres.HTMLSuiteReport_header();
		DataTable DTObj = new DataTable(HTMLResultsReport.strProjectPath
				+ "//TestData//Scenarios.xls", "Execution");
		DataTable DTObjFLow = new DataTable(HTMLResultsReport.strProjectPath
				+ "//TestData//Scenarios.xls", "Scenarios");

		for (int iRow = 1; iRow < DTObj.rowCount(); iRow++) {
			HTMLResultsReport.strScenarioName = DTObj.getCellData(iRow,
					DTObj.getCoulmnNumber("TestScenarioName"));
			String ExecFlag = DTObj.getCellData(iRow,
					DTObj.getCoulmnNumber("Flag"));
			String strScenarioDescription = DTObj.getCellData(iRow,
					DTObj.getCoulmnNumber("ScenarioDescription"));
			String strBrowser = DTObj.getCellData(iRow,
					DTObj.getCoulmnNumber("Browser"));

			if (ExecFlag.toString().equalsIgnoreCase("true")) {
				wrapper.setDriver(strBrowser);
				HTMLResultsReport.currentScenarioStatus = "Scenario Started";
				HTMLResultsReport.SubReport_SNo = 0;
				HTMLResultsReport.SubReport_Pass = 0;
				HTMLResultsReport.SubReport_Fail = 0;
				BusinessComponentsKRC applnFunObj = new BusinessComponentsKRC();

				HTMLres.HTMLReport_header(HTMLResultsReport.strScenarioName);
				for (int iCol = 2; iCol < DTObjFLow.columnCount(); iCol++) {
					if (HTMLResultsReport.currentScenarioStatus
							.equals("Scenario Started")) {
						String ActionName = DTObjFLow.getCellData(iRow, iCol);
						if (ActionName.length() > 0) {
							HTMLres.AddActionName(
									HTMLResultsReport.strScenarioName,
									ActionName);
							Method ActionToExecute = applnFunObj.getClass()
									.getMethod(ActionName);
							ActionToExecute.invoke(applnFunObj);
						}
					} else {
						wrapper.closeBrowser();
						break;
					}
				}
				HTMLres.ResultsSummary_TestScriptName(HTMLResultsReport.strScenarioName);
				HTMLres.AddHtml_SuiteReport(HTMLResultsReport.strScenarioName,
						strScenarioDescription);
			}

		}
		HTMLres.ResultsSummary_strScriptName();
	}

}
