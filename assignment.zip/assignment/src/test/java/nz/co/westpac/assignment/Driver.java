package nz.co.westpac.assignment;

import java.lang.reflect.Method;

import nz.co.westpac.core.DataTable;
import nz.co.westpac.core.HTMLResultsReport;
import nz.co.westpac.core.WrapperClass;

/** This is the main Java Class which will drive the entire execution */
public class Driver {

	public static void main(String[] args) throws Exception {

		String strApplication = "Westpac_KRC";

		WrapperClass wrapper = new WrapperClass();
		HTMLResultsReport HTMLres = new HTMLResultsReport(strApplication);
		HTMLres.HTMLSuiteReport_header();
		
		//This object will be used to fetch all test cases which are marked for execution
		DataTable DTObj = new DataTable(HTMLResultsReport.strProjectPath + "//TestData//Scenarios.xls", "Execution");
		//This object will be used to fetch all the business components which need to be executed for 
		DataTable DTObjFLow = new DataTable(HTMLResultsReport.strProjectPath + "//TestData//Scenarios.xls", "Scenarios");

		//Loop through all the test cases in the Execution sheet and will pick the test cases for execution where flag = true
		for (int iRow = 1; iRow < DTObj.rowCount(); iRow++) {
			
			HTMLResultsReport.strScenarioName = DTObj.getCellData(iRow, DTObj.getCoulmnNumber("TestScenarioName"));
			String ExecFlag = DTObj.getCellData(iRow, DTObj.getCoulmnNumber("Flag"));
			String strScenarioDescription = DTObj.getCellData(iRow, DTObj.getCoulmnNumber("ScenarioDescription"));
			String strBrowser = DTObj.getCellData(iRow, DTObj.getCoulmnNumber("Browser"));

			if (ExecFlag.toString().equalsIgnoreCase("true")) {
				wrapper.setDriver(strBrowser);
				//initializing the HTML Report Variables
				HTMLResultsReport.currentScenarioStatus = "Scenario Started";
				HTMLResultsReport.SubReport_SNo = 0;
				HTMLResultsReport.SubReport_Pass = 0;
				HTMLResultsReport.SubReport_Fail = 0;
				BusinessComponentsKRC applnFunObj = new BusinessComponentsKRC();

				//it will loop through the all business components for each test case
				HTMLres.HTMLReport_header(HTMLResultsReport.strScenarioName);
				for (int iCol = 2; iCol < DTObjFLow.columnCount(); iCol++) {
					if (HTMLResultsReport.currentScenarioStatus.equals("Scenario Started")) {
						String ActionName = DTObjFLow.getCellData(iRow, iCol);
						if (ActionName.length() > 0) {
							HTMLres.AddActionName(HTMLResultsReport.strScenarioName, ActionName);
							Method ActionToExecute = applnFunObj.getClass().getMethod(ActionName);
							ActionToExecute.invoke(applnFunObj);
						}
					} else {
						wrapper.closeBrowser();
						break;
					}
				}
				
				//Updates Final summary of a test case and updates the results to summary html
				HTMLres.ResultsSummary_TestScriptName(HTMLResultsReport.strScenarioName);
				HTMLres.AddHtml_SuiteReport(HTMLResultsReport.strScenarioName, strScenarioDescription);
			}
		}
		HTMLres.ResultsSummary_strScriptName();
	}
}
